<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Remitter extends Model
{
    //
}
