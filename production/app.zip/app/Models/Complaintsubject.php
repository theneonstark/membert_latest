<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Complaintsubject extends Model
{
    protected $fillable = ['subject'];
}
